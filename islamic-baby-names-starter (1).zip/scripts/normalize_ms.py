#!/usr/bin/env python3
# Normalize names to Malay-friendly spellings; map gender; create attributes.
import sys, json, argparse, re
from unidecode import unidecode
from slugify import slugify

def gender_map(g):
  g = (g or "").lower()
  if "female" in g or g == "f": return "F"
  if "male" in g or g == "m": return "M"
  return "U"

REPLACEMENTS = [
  (r"khadija$", "khadijah"),
  (r"ayesha$", "aisyah"),
  (r"aisha$", "aisyah"),
  (r"abdul ", "Abdul "),
]

def malay_spell(name):
  n = unidecode(name or "").strip()
  low = n.lower()
  for pat, rep in REPLACEMENTS:
    low = re.sub(pat, rep, low)
  # Capitalize each word
  return " ".join(w.capitalize() for w in low.split())

def themes(name, meaning):
  s = (f"{name} {meaning or ''}").lower()
  out = set()
  if any(k in s for k in ["rahm", "kind", "compassion", "grace", "rhm"]): out.add("rahmah")
  if any(k in s for k in ["wise", "hikmah", "hakim", "knowledge", "learn"]): out.add("ilmu")
  if any(k in s for k in ["noble", "karim", "honor", "mulia", "exalted"]): out.add("mulia")
  if any(k in s for k in ["strong", "qawi", "brave", "khalid", "firm"]): out.add("kuat")
  if any(k in s for k in ["pure", "suci", "nur", "light", "pious"]): out.add("suci")
  return sorted(out)

def style_guess(name):
  return "classic" if len(name.replace(" ","")) <= 6 else "modern"

def to_record(src):
  name = malay_spell(src.get("name",""))
  g = gender_map(src.get("gender"))
  mean_en = (src.get("meaning") or "").strip() or ""
  rec = {
    "n": name,
    "g": g if g in ("M","F") else ("F" if name.endswith(("a","ah")) else "M"),
    "o": "Arabic",
    "len": len(name.replace(" ", "")),
    "style": style_guess(name),
    "themes": themes(name, mean_en),
    "malay": True,
    "mean_ms": "",          # fill later if you have BM translation
    "mean_en": mean_en,
    "aka": [],
    "src": [f"wikidata:{src.get('qid')}"]
  }
  return rec

def main(inp, outp):
  with open(inp, "r", encoding="utf-8") as f, open(outp, "w", encoding="utf-8") as w:
    for line in f:
      try:
        src = json.loads(line)
        rec = to_record(src)
        w.write(json.dumps(rec, ensure_ascii=False)+"\n")
      except Exception as e:
        continue

if __name__ == "__main__":
  ap = argparse.ArgumentParser()
  ap.add_argument("input")
  ap.add_argument("output")
  args = ap.parse_args()
  main(args.input, args.output)
