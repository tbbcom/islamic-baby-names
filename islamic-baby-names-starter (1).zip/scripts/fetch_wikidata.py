#!/usr/bin/env python3
# Fetch Islamic/Arabic-origin given names via Wikidata SPARQL (API-friendly).
import sys, json, time, argparse, requests
from tqdm import tqdm

SPARQL = "https://query.wikidata.org/sparql"
HEADERS = {"Accept": "application/sparql-results+json", "User-Agent": "islamic-baby-names/1.0 (research; contact: example@example.com)"}

# Query: given names (Q202444) with culture/language Arabic or Islamic-related hints.
QUERY_TEMPLATE = """
SELECT DISTINCT ?item ?itemLabel ?genderLabel ?meaning ?translit ?lang WHERE {
  ?item wdt:P31 wd:Q202444.             # instance of given name
  OPTIONAL { ?item wdt:P21 ?gender. }
  OPTIONAL { ?item wdt:P1559 ?translit. }     # name in native language
  OPTIONAL { ?item wdt:P734 ?family. }        # surname of given name (ignore)
  OPTIONAL { ?item wdt:P282 ?writing. }       # writing system
  OPTIONAL {
    ?item wdt:P407 ?langEnt.                 # language of work or name
    ?langEnt rdfs:label ?lang FILTER (lang(?lang) = "en" || lang(?lang)="ar")
    BIND(?lang AS ?lang)
  }
  OPTIONAL { ?item wdt:P5138 ?meaning. }     # meaning of name (if present)
  SERVICE wikibase:label { bd:serviceParam wikibase:language "en,ar,ms,id" }
}
LIMIT %d
"""

def run(limit=10000, sleep=0.2, out="data/raw/wikidata.jsonl"):
  q = QUERY_TEMPLATE % limit
  r = requests.get(SPARQL, params={"query": q, "format":"json"}, headers=HEADERS, timeout=60)
  r.raise_for_status()
  js = r.json()
  rows = js.get("results", {}).get("bindings", [])
  with open(out, "w", encoding="utf-8") as f:
    for b in rows:
      rec = {
        "qid": b["item"]["value"].split("/")[-1],
        "name": b.get("itemLabel", {}).get("value"),
        "gender": b.get("genderLabel", {}).get("value"),
        "meaning": b.get("meaning", {}).get("value"),
        "translit": b.get("translit", {}).get("value"),
        "lang": b.get("lang", {}).get("value")
      }
      if rec["name"]:
        f.write(json.dumps(rec, ensure_ascii=False)+"\n")
  time.sleep(sleep)

if __name__ == "__main__":
  ap = argparse.ArgumentParser()
  ap.add_argument("--limit", type=int, default=10000)
  ap.add_argument("--sleep", type=float, default=0.2)
  ap.add_argument("--out", default="data/raw/wikidata.jsonl")
  args = ap.parse_args()
  run(args.limit, args.sleep, args.out)
