# Islamic Baby Names — Dataset & Generator (Starter)

This is a **starter repo** to build a 5k+ Islamic baby names dataset and ship it to a **Blogger-friendly widget**.

## Highlights
- Sources names via **Wikidata SPARQL** (API-friendly, non-scraping).
- Optional scraping adapters (respect robots.txt, rate limits).
- Cleans, dedupes, normalizes to **Malay-friendly spellings**.
- Exports `data/processed/islamic-names.ms.json` (consumed by the widget).
- JS app (`src/ib-names.js`) **lazy-loads** the dataset and caches in `localStorage`.
- Build via **terser** to `dist/ib-names.min.js` for CDN (jsDelivr) or Blogger inline.

## Quickstart
```bash
# 1) Python env
python -m venv .venv && source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt

# 2) Fetch from Wikidata (safe / API-based)
python scripts/fetch_wikidata.py --limit 10000 --sleep 0.2

# 3) Normalize to Malay-friendly and dedupe
python scripts/normalize_ms.py data/raw/wikidata.jsonl data/processed/names.norm.jsonl
python scripts/merge_dedupe.py data/processed/names.norm.jsonl data/processed/islamic-names.ms.json

# 4) Build frontend JS
npm i
npm run build

# 5) Host on GitHub + jsDelivr
# tag -> v1.0.0, then use
# https://cdn.jsdelivr.net/gh/<user>/<repo>@v1.0.0/dist/ib-names.min.js
```

## Ethically Sourcing Data (avoid bans)
- Prefer **official APIs** (Wikidata SPARQL) vs. HTML scraping.
- If scraping, **check robots.txt**, set **User-Agent**, **sleep** between requests, and **cache** responses.
- Keep a **source column** and **license notes** per record.

## Files
- `scripts/fetch_wikidata.py` — query given names of Arabic/Islamic origin (with gender, transliteration, meaning when available).
- `scripts/normalize_ms.py` — normalize spellings to Malay-friendly variants (rule-based).
- `scripts/merge_dedupe.py` — dedupe with phonetic+token rules; pick best definition.
- `scripts/build_json.py` — optional final shaping to the exact JSON used by the widget.
- `src/ib-names.js` — Blogger widget logic (lazy-load dataset).
- `index.html` — minimal demo that mirrors your Blogger static page.
- `data/raw/` — fetched JSONL from sources.
- `data/processed/` — cleaned outputs (final `islamic-names.ms.json`).

## Schema of final JSON
```json
[
  {
    "n": "Aisyah",
    "g": "F",
    "o": "Arabic",
    "len": 6,
    "style": "classic",
    "themes": ["mulia"],
    "malay": true,
    "mean_ms": "Hidup, isteri Nabi",
    "mean_en": "Alive; wife of the Prophet",
    "aka": ["Aisha","Ayesha"],
    "src": ["wikidata:Q12345"]
  }
]
```

## License
- You are responsible to ensure names/definitions respect source licenses. Wikidata is CC0.
