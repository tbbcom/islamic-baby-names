/* ib-names.js — dataset loader and minimal render for Blogger */
(function(){
  'use strict';
  const CDN_JSON = 'data/processed/islamic-names.ms.json'; // replace with CDN when deployed
  const LS_KEY = 'tbb_names_v100';

  async function getData(){
    const cached = localStorage.getItem(LS_KEY);
    if(cached){
      try { return JSON.parse(cached); } catch {}
    }
    const res = await fetch(CDN_JSON, {credentials:'omit'});
    const data = await res.json();
    try { localStorage.setItem(LS_KEY, JSON.stringify(data)); } catch {}
    return data;
  }

  // expose for your Blogger widget code to call
  window.IBNames = { getData };
})();