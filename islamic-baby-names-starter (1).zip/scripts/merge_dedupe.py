#!/usr/bin/env python3
# Merge JSONL records, dedupe by normalized key
import sys, json, argparse

def norm_key(name): return "".join(ch.lower() for ch in name if ch.isalnum())

def main(inp, outp):
  seen = {}
  with open(inp, "r", encoding="utf-8") as f:
    for line in f:
      try:
        rec = json.loads(line)
        key = norm_key(rec["n"])
        if key in seen:
          a = seen[key]
          if len((rec.get("mean_en") or "")) > len((a.get("mean_en") or "")):
            a["mean_en"] = rec.get("mean_en") or a.get("mean_en")
          a["themes"] = sorted(set((a.get("themes") or []) + (rec.get("themes") or [])))
          a["src"] = sorted(set((a.get("src") or []) + (rec.get("src") or [])))
          seen[key] = a
        else:
          seen[key] = rec
      except:
        pass
  final = list(seen.values())
  with open(outp, "w", encoding="utf-8") as w:
    json.dump(final, w, ensure_ascii=False, indent=2)

if __name__ == "__main__":
  ap = argparse.ArgumentParser()
  ap.add_argument("input")
  ap.add_argument("output")
  args = ap.parse_args()
  main(args.input, args.output)
