#!/usr/bin/env python3
# Optionally reshape to smaller fields, sort, and split by initial for sharding.
import sys, json, argparse, os

def main(inp, outp, shard=False):
  with open(inp, "r", encoding="utf-8") as f:
    arr = json.load(f)
  arr.sort(key=lambda x: x["n"])
  if not shard:
    with open(outp, "w", encoding="utf-8") as w:
      json.dump(arr, w, ensure_ascii=False, separators=(",",":"))
  else:
    base = os.path.splitext(outp)[0]
    buckets = {}
    for r in arr:
      k = r["n"][0].upper()
      buckets.setdefault(k, []).append(r)
    for k, recs in buckets.items():
      with open(f"{base}.{k}.json", "w", encoding="utf-8") as w:
        json.dump(recs, w, ensure_ascii=False, separators=(",",":"))

if __name__ == "__main__":
  ap = argparse.ArgumentParser()
  ap.add_argument("input")
  ap.add_argument("output")
  ap.add_argument("--shard", action="store_true")
  args = ap.parse_args()
  main(args.input, args.output, args.shard)
